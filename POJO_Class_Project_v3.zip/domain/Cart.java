package com.categoryshopping.domain;

import java.util.List;

public class Cart {
	private int cartId;
	private List<CartDetails> cartDetail;
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public List<CartDetails> getCartDetail() {
		return cartDetail;
	}
	public void setCartDetail(List<CartDetails> cartDetail) {
		this.cartDetail = cartDetail;
	}
	

}
