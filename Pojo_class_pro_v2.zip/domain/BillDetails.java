package com.categoryshopping.domain;

import java.util.List;

public class BillDetails {
	private int billId;
	private double totalAmount;
	private BillingItems bill;
	private UserDetails user;
	
	public double getTotalamount() {
		return totalAmount;
	}
	public void setTotalamount(double totalamount) {
		this.totalAmount = totalamount;
	}
	
	
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	public UserDetails getUser() {
		return user;
	}
	public void setUser(UserDetails user) {
		this.user = user;
	}
	public BillingItems getBill() {
		return bill;
	}
	public void setBill(BillingItems bill) {
		this.bill = bill;
	}
}
