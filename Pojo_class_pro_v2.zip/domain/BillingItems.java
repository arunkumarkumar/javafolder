package com.categoryshopping.domain;

import java.util.List;

public class BillingItems {
	private int billingId;
	private double billingAmount;
	private List<CartDetails> cart;	
	public int getBilling_id() {
		return billingId;
	}
	public void setBilling_id(int billing_id) {
		this.billingId = billing_id;
	}
	public double getBilling_amount() {
		return billingAmount;
	}
	public void setBilling_amount(double billing_amount) {
		this.billingAmount = billing_amount;
	}
	public List<CartDetails> getCart() {
		return cart;
	}
	public void setCart(List<CartDetails> cart) {
		this.cart = cart;
	}
	


}
