package com.categoryshopping.domain;

import java.util.List;

public class PaymentDetails {
	private int id;
	private double amount;
	private String orderStatus;
	private BillDetails payment;
	
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public BillDetails getPayment() {
		return payment;
	}
	public void setPayment(BillDetails payment) {
		this.payment = payment;
	}

}
