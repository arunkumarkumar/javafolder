package com.categoryshopping.domain;

import java.util.List;

public class CartDetails {
	private int cartId;
	private List<ProductDetails> product;
	private int quantity[]=new int[product.size()];
	private double cartPrice;
	

	public double getCart_price() {
		return cartPrice;
	}
	public void setCart_price(double cart_price) {
		this.cartPrice = cart_price;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public List<ProductDetails> getProduct() {
		return product;
	}
	public void setProduct(List<ProductDetails> product) {
		this.product = product;
	}
	public int[] getQuantity() {
		return quantity;
	}
	public void setQuantity(int[] quantity) {
		this.quantity = quantity;
	}
}
