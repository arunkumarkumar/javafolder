package com.categoryshopping.domain;

import java.util.List;

public class CategoryDetails {
	private int id;
	private  String categories;
	private List<ProductDetails>lst;
	public int getid() {
		return id;
	}
	public void setCategories_id(int id) {
		this.id = id;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public List<ProductDetails> getLst() {
		return lst;
	}
	public void setLst(List<ProductDetails> lst) {
		this.lst = lst;
	}
  
}

